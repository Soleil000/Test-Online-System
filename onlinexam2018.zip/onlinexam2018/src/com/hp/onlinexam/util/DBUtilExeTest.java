package com.hp.onlinexam.util;

/**
 * @author asus-pc
 * 用于execute方法的练习
 */
public class DBUtilExeTest {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		DBUtil db = new DBUtil();
		/**
		 * 如果插入部分字段在表名;.后写上字段列表。
		 */
		String sql = "insert into course(name) values('计算机网络')";
		db.execute(sql);
		String sql2 = "insert into course (name) values(?)";
		db.execute(sql2, new Object[] {"SSM"});
		/**
		 * 练习：删除课程名称是ssm2的课程信息
		 */
		String sql3 = "delete from course where name = 'SSM'";
		db.execute(sql3);
		
		String sql4 = "delete from course where name = ?";
		db.execute(sql4, new Object[] {"计算机网络"});
		
	}

}
