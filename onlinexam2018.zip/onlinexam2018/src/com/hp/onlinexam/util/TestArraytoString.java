package com.hp.onlinexam.util;

public class TestArraytoString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] strArray = new String[] {"1","2","4","6"};
		StringBuffer sb = new StringBuffer();
		for(int i=0; i<strArray.length; i++) {
			if(i==0)
				sb.append(strArray[i]);
			else
				sb.append(","+strArray[i]);
		}

		String s = sb.toString();
		System.out.println(s);
	}

}
