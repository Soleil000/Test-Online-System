package com.hp.onlinexam.util;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import com.hp.onlinexam.po.Course;
import com.hp.onlinexam.po.Test;

public class DBUtilTest {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		String sql = "select * from course where name = 'javaweb'";
		DBUtil db = new DBUtil();
		/**
		 *如果一个方法是静态方法，可以使用类名，方法调用
		 *如果是普通方法，必须使用构造方法创建对象调用 
		 *
		 *数组缺点：一旦创建，大小不可变，不便于删除
		 *集合框架：List,Set,Map
		 *Map的优势在于使用键值对存储，使用键值对的好处在于键是唯一的，可以通过键直接获取值。
		 *
		 *如果在调用的方法体上有抛出异常throws **Exception
		 *在调用方法时有两种解决方案：
		 *1. try-catch包裹，异常处理
		 *2. 继续在调用本方法的方法体上throw **Exception
		 *
		 *java里通过包名来区分类名相同的情况， java.util
		 *
		 *<>表示泛型，使用泛型的好处在于对键值的类型描述
		 */
		 /**
		 * 1---Map<String, Object> getObject(String sql)----
		 *适用场景：
		 *1.sql已经提前知道
		 *2.参数较少，写到sql语句中
		 *3.可以用来获取对象。获取对象的形式是键值对
		 *4.尤其用于多表无法封装成一个对象的场景（仅用到部分字段，不能填充实体）
		 *适用于获取一条记录的情况
		 */
		Map<String, Object> courseMap = db.getObject(sql);
		/**
		 * debug模式和run模式
		 * 开发的时候使用debug，可以看到中间过程，能够在自己关注的代码暂停
		 * 能够一行行执行代码
		 * 在自己关注的代码左侧双击可以打断点
		 * 如果debug模式没有任何断点和run模式一致
		 * 
		 */
		System.out.println(courseMap);
		/**遍历Map!!!
		 * 使用iterator
		 * map的存储方式使用键值对，entry可以理解为键值对。
		 */
		Iterator<Entry<String, Object>> it = courseMap.entrySet().iterator();
		while(it.hasNext()) {
			Entry<String, Object> entry= it.next();
			System.out.println(entry.getKey()+"@@@"+entry.getValue());
		}
		/**
		 * 在一个方法里变量不能定义两次，但可以重复赋值
		 */
		/**
		 * 1---Map<String, Object> getObject(String sql, )----
		 * 适用于获取一条记录的情况
		 */
		String sql2 = "select * from course where name = ?";
		Map<String, Object>courseMap2 = db.getObject(sql2, new Object[] {"javaweb"});
		System.out.println(courseMap2);
		/**
		 * 练习：test表 查找课程id是1，且教师id是2的试卷
		 */
		String sql3 = "select * from test where courseId = ? and teacherId=?";
		Map<String, Object>courseMap3 = db.getObject(sql3, new Object[] {1,2});
		System.out.println(courseMap3);
		Iterator<Entry<String,Object>> it2 = courseMap3.entrySet().iterator();
		while(it2.hasNext()) {
			Entry<String, Object> entry = it2.next();
			System.out.println(entry.getKey()+"@@@"+entry.getValue());
		}
		/**
		 * 将查询到的结果直接封装成对象
		 * Object getObject(Class<?> type,String sql, new Object[] paramList)
		 * 第一个参数表示要封装成的类类型
		 * type需要是我们提供的po或着vo， String不行
		 * 返回结果是封装好的po或vo，需要强制转换
		 */
		Course c = (Course)db.getObject(Course.class, sql2, new Object[] {"javaweb"});
		System.out.println("第三个方法的输出:"+c.getName());
		
		/**
		 * 练习：从Test表中查询出一条记录，封装成Test对象，并输出所有字段。
		 */
		Test t = (Test)db.getObject(Test.class, sql3, new Object[] {1,2});
		System.out.println(t);
	}
	/**
	 * 返回值不同，方法参数相同，不能作为重载的判断，因为返回值可以不接收，无法判断该调用哪个方法。
	 */

}
