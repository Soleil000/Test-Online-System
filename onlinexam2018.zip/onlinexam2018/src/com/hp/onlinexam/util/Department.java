package com.hp.onlinexam.util;

public enum Department {
	开发,
	测试
}
