package com.hp.onlinexam.util;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.hp.onlinexam.po.Papers;
import com.hp.onlinexam.po.Test;

public class DBUtilQueryTest {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		/**
		 *查询多条记录
		 */
		DBUtil db = new DBUtil();
		String sql = "select * from test";
		List<Map<String,Object>> testList = db.getQueryList(sql);
		for(int i=0; i<testList.size(); i++) {
			Map<String, Object> testMap = testList.get(i);
			Iterator<Entry<String, Object>> it = testMap.entrySet().iterator();
			while(it.hasNext()) {
				Entry<String, Object> entry = it.next();
				System.out.print(entry.getKey()+"---"+entry.getValue()+"   ");
			}
			System.out.println();
		}
		/**
		 * 练习：：test表 查找课程id是1，且教师id是2的试卷
		 */
		String sql2 = "select * from test where courseId = ? and teacherId = ?";
		List<Map<String, Object>> testList2 = db.getQueryList(sql2, new Object[]{1,2});
		for(int i=0; i<testList2.size(); i++) {
			Map<String, Object> testMap = testList.get(i);
			Iterator<Entry<String, Object>> it = testMap.entrySet().iterator();
			while(it.hasNext()) {
				Entry<String, Object> entry = it.next();
				System.out.print(entry.getKey()+"---"+entry.getValue()+"   ");
			}
			System.out.println();
		}
		/**
		 * 数组是一组相同数据类型的集合
		 * 声明：仅仅是定义数据类型和变量名
		 * 定义：除了声明外，有赋值
		 * 数组声明时，[]可以放在变量前也可以放变量后
		 */
		String [] strArray;
		String strArray2[];
		String [] strArray3 = new String[] {"pgthree","lixiaolu"};
		String [] strArray4 = {"pgthree","lixiaolu"};
		String [] strArray5 = new String[3];
		
		List testObjectList = db.getQueryList(Test.class, sql2, new Object[]{1,2});
		for(Object o:testObjectList) {
			Test t = (Test) o;
			System.out.println(t);
		}
		
		/**
		 * 练习1：查询姓张的学生的学生成绩，查询结果要包括学生姓名
		 */
		String sql3 = "select score,name from student,stu_test where student.id = stu_test.studentId and name like '张%'";
		List<Map<String,Object>> papersList = db.getQueryList(sql3);
		for(int i=0; i<papersList.size(); i++) {
			Map<String, Object> papersMap = papersList.get(i);
			Iterator<Entry<String, Object>> it = papersMap.entrySet().iterator();
			while(it.hasNext()) {
				Entry<String, Object> entry = it.next();
				System.out.print(entry.getKey()+"---"+entry.getValue()+"   ");
			}
			System.out.println();
		}
		/**
		 * 练习2：查询李思老师的排课表
		 */
		String sql4 = "select t.name as tname, c.name as cname, s.name as sname from teacher t, teach_course tc, course c, stu_class s"
				+ " where t.id = tc.teacherId and c.id = tc.courseId and s.id = tc.classId"
				+ " and t.name = ?";
		List<Map<String,Object>> teachList = db.getQueryList(sql4, new Object[] {"李思"});
		for(int i=0; i<teachList.size(); i++) {
			Map<String, Object> teachMap = teachList.get(i);
			Iterator<Entry<String, Object>> it = teachMap.entrySet().iterator();
			while(it.hasNext()) {
				Entry<String, Object> entry = it.next();
				System.out.print(entry.getKey()+"--"+entry.getValue()+"   ");
			}
			System.out.println();
		}
		/**
		 * 练习3：查询所有的试题信息
		 */
		String sql5 = "select * from test";
		List testObjectList1 = db.getQueryList(Test.class, sql5, new Object[] {});
		for(Object o:testObjectList1) {
			Test t = (Test) o;
			System.out.println(t);
		}
		/**
		 * 起别名的好处在于多表查询可以表名简写,字段也可以起别名,模糊查询使用like
		 */
		
	}

}
