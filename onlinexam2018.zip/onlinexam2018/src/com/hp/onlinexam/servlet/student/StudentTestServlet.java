package com.hp.onlinexam.servlet.student;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hp.onlinexam.po.Papers;
import com.hp.onlinexam.po.Questions;
import com.hp.onlinexam.po.Student;
import com.hp.onlinexam.service.teacher.IPaperService;
import com.hp.onlinexam.service.teacher.IQuestionService;
import com.hp.onlinexam.service.teacher.ITestService;
import com.hp.onlinexam.service.teacher.PaperService;
import com.hp.onlinexam.service.teacher.QuestionService;
import com.hp.onlinexam.service.teacher.TestService;
import com.hp.onlinexam.util.ToolUtil;

@WebServlet("/StudentTestServlet")
public class StudentTestServlet extends HttpServlet{
	ITestService ts = new TestService();
	IQuestionService qs = new QuestionService();
	IPaperService ps = new PaperService();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String testId = req.getParameter("testId");
		Student s = (Student) req.getSession().getAttribute("user");
		Map testMap = ts.findStudentTestsById(s.getId(), Integer.valueOf(testId));
		String questionIds = (String)testMap.get("questions");
		List quesList = qs.findQuestionByIds(questionIds);
		//计算每道题的分值
		double scoreperques = Double.valueOf((String)testMap.get("scores"))/quesList.size();
		req.getSession().setAttribute("test", testMap);
		req.getSession().setAttribute("quesList", quesList);
		req.setAttribute("scoreperques", scoreperques);
		req.getRequestDispatcher("student/exam.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Student s = (Student) req.getSession().getAttribute("user");
		//交卷时间
		String time = req.getParameter("hidden1");
		List quesList = (List) req.getSession().getAttribute("quesList");
		Map test = (Map) req.getSession().getAttribute("test");
		
		if(null == quesList||quesList.size()<1){
			return;
		}
		//错题id和错题答案
		StringBuffer wrongQueId = new StringBuffer();
		StringBuffer wrongAns = new StringBuffer();
		//错题数量
		int wrongQueNum = 0;
		for(int i=0; i<quesList.size(); i++) {
			//页面接收的答案
			Questions q = (Questions) quesList.get(i); 
			String ans = req.getParameter("ques_"+q.getId()).toUpperCase();
			if(!q.getAns().equals(ans)) {
				wrongQueNum++;
				wrongQueId.append(q.getId()).append(",");;
				wrongAns.append(ans).append(",");;
			}
		}
		Papers p = new Papers();
		p.setTestId((int)test.get("id"));
		p.setCourseId((int)test.get("courseId"));
		p.setTime(time);
		if(quesList.size()>wrongQueNum) {
			p.setScore(1.0*Integer.parseInt((String) (test.get("scores")))/quesList.size()*(quesList.size()-wrongQueNum));
		}
		else
			p.setScore(0);
		String wrongQueIdString = wrongQueId.toString();
		String wrongAnsString = wrongAns.toString();
		if (wrongQueIdString.endsWith(",")){
			wrongQueIdString = wrongQueIdString.substring(0, wrongQueIdString.length()-1);
			wrongAnsString = wrongAnsString.substring(0, wrongAnsString.length()-1);
		}
		p.setWrongQueId(wrongQueIdString);
		p.setWrongAns(wrongAnsString);
		p.setStudentId(s.getId());
		Date date = new Date();
		p.setCreateDate(date);
		ps.save(p);
		resp.sendRedirect(req.getContextPath()+"/student/index.jsp");
	}
	
}
