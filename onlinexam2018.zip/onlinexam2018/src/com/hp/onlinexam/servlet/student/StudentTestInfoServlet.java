package com.hp.onlinexam.servlet.student;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hp.onlinexam.po.Questions;
import com.hp.onlinexam.po.Student;
import com.hp.onlinexam.service.teacher.IPaperService;
import com.hp.onlinexam.service.teacher.IQuestionService;
import com.hp.onlinexam.service.teacher.ITestService;
import com.hp.onlinexam.service.teacher.PaperService;
import com.hp.onlinexam.service.teacher.QuestionService;
import com.hp.onlinexam.service.teacher.TestService;

@WebServlet("/StudentTestInfoServlet")
public class StudentTestInfoServlet extends HttpServlet{
	IPaperService ps = new PaperService();
	ITestService ts = new TestService();
	IQuestionService qs = new QuestionService();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id = req.getParameter("id");
		Student s = (Student) req.getSession().getAttribute("user");
		Map paperMap = ps.getPaperInfoByStudentId(Integer.valueOf(id), s.getId());
		String questionIds = (String)paperMap.get("questions");
		List quesList = qs.findQuestionByIds(questionIds);
		//计算每道题的分值
		double scoreperques = Double.valueOf((String)paperMap.get("scores"))/quesList.size();
		//错题列表
		List wrongList = qs.findQuestionByIds((String)paperMap.get("wrongQueId"));
		//错题答案
		String wrongA = (String)paperMap.get("wrongAns");
		String[] wrongAns =  wrongA.split(",");
		for(int i=0; i<wrongList.size(); i++) {
			Questions q = (Questions) wrongList.get(i);
			q.setAns(wrongAns[i]);
		}
		req.setAttribute("paper", paperMap);
		req.setAttribute("quesList", quesList);
		req.setAttribute("wrongList", wrongList);
		req.setAttribute("scoreperques", scoreperques);
		req.getRequestDispatcher("student/pastexaminfo.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

}
