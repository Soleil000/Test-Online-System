package com.hp.onlinexam.servlet.student;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hp.onlinexam.po.Student;
import com.hp.onlinexam.service.teacher.ITestService;
import com.hp.onlinexam.service.teacher.TestService;

@WebServlet("/RecentTestServlet")
public class RecentTestServlet extends HttpServlet{
	ITestService ts = new TestService();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String key = req.getParameter("stname");
		if(null==key) {
			key = "";
		}
		Student s = (Student) req.getSession().getAttribute("user");
		Timestamp currData = new Timestamp(System.currentTimeMillis()); 
		List testsList = ts.getTestByStudent(s.getId(), currData, key);
		if(testsList.size()==0) {
			req.setAttribute("error", "无相关搜索结果！");
		}
		req.setAttribute("testsList", testsList);
		req.getRequestDispatcher("student/main.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}
	
}
