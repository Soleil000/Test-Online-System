package com.hp.onlinexam.servlet.teacher;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hp.onlinexam.po.Teacher;
import com.hp.onlinexam.service.teacher.IQuestionService;
import com.hp.onlinexam.service.teacher.ITestService;
import com.hp.onlinexam.service.teacher.QuestionService;
import com.hp.onlinexam.service.teacher.TestService;

@WebServlet("/TestDetailInfoServlet")
public class TestDetailInfoServlet extends HttpServlet{
	private ITestService ts = new TestService();
	private IQuestionService qs = new QuestionService();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Teacher t = (Teacher) req.getSession().getAttribute("user");
		String id = req.getParameter("id");
		Map<String, Object> testMap = ts.findTestById(Integer.valueOf(id), t.getId());
		String quesIds = (String) testMap.get("questions");
		List quesList = qs.findQuestionByIds(quesIds);
		req.setAttribute("test", testMap);
		req.setAttribute("quesList", quesList);
		req.getRequestDispatcher("teacher/testinfo.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}
	
}
