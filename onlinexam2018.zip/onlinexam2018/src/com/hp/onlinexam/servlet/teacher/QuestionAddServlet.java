package com.hp.onlinexam.servlet.teacher;

import java.util.List;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hp.onlinexam.po.Questions;
import com.hp.onlinexam.service.admin.CourseService;
import com.hp.onlinexam.service.admin.ICourseService;
import com.hp.onlinexam.service.teacher.IQuestionService;
import com.hp.onlinexam.service.teacher.QuestionService;

@WebServlet("/QuestionAddServlet")
public class QuestionAddServlet extends HttpServlet{
	private IQuestionService qs = new QuestionService();
	private ICourseService cs = new CourseService();
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		List courseList = cs.findAllCourses();
		req.setAttribute("courseList", courseList);
		req.getRequestDispatcher("teacher/quesadd.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String courseId = req.getParameter("courseInfo");
		String queType = req.getParameter("queType");
		String queTitle = req.getParameter("queTitle");
		String choiceA = req.getParameter("choiceA");
		String choiceB = req.getParameter("choiceB");
		String choiceC = req.getParameter("choiceC");
		String choiceD = req.getParameter("choiceD");
		String ans = req.getParameter("ans");
		Questions q = new Questions(Integer.valueOf(courseId),Integer.valueOf(queType),queTitle,choiceA,choiceB,choiceC,choiceD,ans);
		qs.addQuestion(q);
		resp.sendRedirect(req.getContextPath()+"/QuestionQueryServlet");
	}

}
