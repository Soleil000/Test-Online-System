package com.hp.onlinexam.servlet.teacher;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hp.onlinexam.po.Course;
import com.hp.onlinexam.po.Teacher;
import com.hp.onlinexam.po.Test;
import com.hp.onlinexam.service.admin.CourseService;
import com.hp.onlinexam.service.admin.ICourseService;
import com.hp.onlinexam.service.admin.IStuClassService;
import com.hp.onlinexam.service.admin.StuClassService;
import com.hp.onlinexam.service.teacher.IQuestionService;
import com.hp.onlinexam.service.teacher.QuestionService;
import com.hp.onlinexam.util.ToolUtil;

@WebServlet("/TestAddServlet")
public class TestAddServlet extends HttpServlet{
	private IQuestionService qs = new QuestionService();
	private IStuClassService scs = new StuClassService();
	private ICourseService cs = new CourseService();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		/**
		 * 在用户登陆时把用户信息放到session中
		 * req.getSession().setAttribute("user", t);
		 * 在用户可以访问的权限内 req.getSession().getAttribute("user")来获取当前对象
		 */
		Teacher t = (Teacher)req.getSession().getAttribute("user");
		List courseList = cs.findCoursesByTeacherId(t.getId());
		req.setAttribute("courseList", courseList);
		List classesList = scs.findStuClassesByTeacherId(t.getId());
		req.setAttribute("classesList", classesList);
		req.getRequestDispatcher("teacher/testadd.jsp").forward(req, resp);
	}
	/**
	 * 组卷
	 * 1.从页面获取试卷基本信息，把基本信息传递到下一个页面
	 * 2.获取试卷题目相关信息，随机抽题组卷，把试题传递到下一个页面
	 * 3.页面跳转
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		/**
		 * 从页面获取数据
		 */
		String courseId = req.getParameter("courseInfo");
		String testName = req.getParameter("testname");
		String endDate = req.getParameter("enddate");
		String sinScores = req.getParameter("sinscores"); //单选分值
		String sinNum = req.getParameter("sinnum");
		String testTime = req.getParameter("testtime");
		/**
		 * 页面如果是复选框，通过getParameterValues获取值，获取的数据类型是数组
		 */
		String[] classCheck = req.getParameterValues("classCheck");
		/**
		 * 数据-->test表的转化工作：封装成test对象，并插入数据库
		 * 1.endDate类型转换
		 * 2.classCheck字符串数组转换成字符串classIds
		 * 3.根据sinNum提供的试题数量随机出题（集合set），并拿到题号组成的数组
		 */
		//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		//Date date = new Date();
		Timestamp ts = new Timestamp(System.currentTimeMillis());
		try {
			//date = sdf.parse(endDate);
			ts = Timestamp.valueOf(endDate); 
			System.out.println(ts);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		String classIds = ToolUtil.arraytoString(classCheck);
		
		List<Map<String,Object>> quesList = qs.collectQuestions(Integer.valueOf(courseId), Integer.valueOf(sinNum));
		
		String questions = qs.testQuestionIds(quesList);
		
		String classNames = scs.findClassNamesByIds(classIds);
		//封装成对象减少代码量
		Test t = new Test(Integer.valueOf(courseId),testName,ts,questions,classIds,sinScores,Integer.valueOf(testTime));
		
		Map<String, Object> c = cs.findCourseById(Integer.valueOf(courseId));
		
		req.setAttribute("classNames", classNames);
		req.getSession().setAttribute("test", t);
		req.setAttribute("quesList", quesList);
		req.setAttribute("c", c);
		req.getRequestDispatcher("teacher/test.jsp").forward(req, resp);
	}

}	
