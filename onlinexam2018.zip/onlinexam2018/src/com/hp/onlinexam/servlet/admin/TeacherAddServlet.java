package com.hp.onlinexam.servlet.admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hp.onlinexam.po.Teacher;
import com.hp.onlinexam.service.admin.IStuClassService;
import com.hp.onlinexam.service.admin.ITeacherService;
import com.hp.onlinexam.service.admin.StuClassService;
import com.hp.onlinexam.service.admin.TeacherService;
import com.hp.onlinexam.util.Department;
import com.hp.onlinexam.util.Encrypt;

@WebServlet("/TeacherAddServlet")
public class TeacherAddServlet extends HttpServlet{

	private Teacher tc = new Teacher();
	private ITeacherService scs = new TeacherService();
	private Encrypt e = new Encrypt();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.setAttribute("deptList", Department.values());
		req.getRequestDispatcher("manager/teacheradd.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String tName = req.getParameter("teaname");
		String password = req.getParameter("pwd");
		String pwd = e.convertMD5(password);
		String deptName = req.getParameter("depInfo");
		tc.setName(tName);
		tc.setPwd(pwd);
		tc.setDeptName(deptName);
		scs.addTeacher(tc);
		/**
		 * getRequestDispatcher带着request和response跳转
		 * 若不需要保留请求和相应则使用resp.setRedirect
		 */
		resp.sendRedirect(req.getContextPath()+"/TeacherQueryServlet");
	}
	
}
