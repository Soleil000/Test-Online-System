package com.hp.onlinexam.servlet.admin;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hp.onlinexam.po.TeacherCourse;
import com.hp.onlinexam.service.admin.CourseService;
import com.hp.onlinexam.service.admin.ICourseService;



@WebServlet("/TeacherCourseQueryServlet")
public class TeacherCourseQueryServlet extends HttpServlet{
	private ICourseService cs = new CourseService();
	private TeacherCourse tc = new TeacherCourse();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String key = req.getParameter("tcname");
		if(null==key) {
			key = "";
		}
		List tcList = cs.findTeacherCourseByKey(key);
		if(tcList.size()==0) {
			req.setAttribute("error", "无相关搜索结果！");
		}
		req.setAttribute("tcList", tcList);
		req.getRequestDispatcher("manager/teachcoursemanage.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doPost(req, resp);
	}
	
}


