package com.hp.onlinexam.servlet.admin;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hp.onlinexam.po.TeacherCourse;
import com.hp.onlinexam.service.admin.CourseService;
import com.hp.onlinexam.service.admin.ICourseService;
import com.hp.onlinexam.service.admin.IStuClassService;
import com.hp.onlinexam.service.admin.ITeacherService;
import com.hp.onlinexam.service.admin.StuClassService;
import com.hp.onlinexam.service.admin.TeacherService;
import com.hp.onlinexam.vo.TeacherCourseView;


@WebServlet("/TeacherCourseModifyServlet")
public class TeacherCourseModifyServlet extends HttpServlet{

	private TeacherCourse tc = new TeacherCourse();
	private TeacherCourseView tcv = new TeacherCourseView();
	private ICourseService cs = new CourseService();
	private IStuClassService scs = new StuClassService();
	private ITeacherService ts = new TeacherService();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id = req.getParameter("id");
		
		tcv = cs.findTeacherCourseById(Integer.valueOf(id));
		req.setAttribute("TeachCourse", tcv);
		List classList = scs.findClassNames();
		req.setAttribute("classList", classList);
		List couList = cs.findAllCourses();
		req.setAttribute("courseList", couList);
		List teaList = ts.findTeachers("");
		req.setAttribute("teacherList", teaList);
		req.getRequestDispatcher("manager/teachcoursemodify.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id = req.getParameter("tcId");
		String courseId = req.getParameter("courseInfo");
		String teacherId = req.getParameter("teacherInfo");
		String classId = req.getParameter("classInfo");
		tc.setCourseId(Integer.valueOf(courseId));
		tc.setTeacherId(Integer.valueOf(teacherId));
		tc.setClassId(Integer.valueOf(classId));
		tc.setId(Integer.valueOf(id));
		cs.updateTeacherCourse(tc);
		resp.sendRedirect(req.getContextPath()+"/TeacherCourseQueryServlet");
	}

}
