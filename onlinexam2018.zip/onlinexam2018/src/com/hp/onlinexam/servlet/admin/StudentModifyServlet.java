package com.hp.onlinexam.servlet.admin;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hp.onlinexam.po.Student;
import com.hp.onlinexam.service.admin.IStuClassService;
import com.hp.onlinexam.service.admin.IStudentService;
import com.hp.onlinexam.service.admin.StuClassService;
import com.hp.onlinexam.service.admin.StudentService;
import com.hp.onlinexam.util.Department;
import com.hp.onlinexam.util.Encrypt;

@WebServlet("/StudentModifyServlet")
public class StudentModifyServlet extends HttpServlet{

	private IStudentService ss = new StudentService();
	private Student s = new Student();
	private IStuClassService scs = new StuClassService();
	private Encrypt e = new Encrypt();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id = req.getParameter("id");
		Map<String, Object> stuMap = ss.findStudentById(Integer.valueOf(id));
		req.setAttribute("Student", stuMap);
		List classList = scs.findClassNames();
		req.setAttribute("classList", classList);
		req.setAttribute("deptList", Department.values());
		req.getRequestDispatcher("manager/studentmodify.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id = req.getParameter("stuId");
		String deptName = req.getParameter("depInfo");
		String password = req.getParameter("pwd");
		String pwd = e.convertMD5(password);
		String name = req.getParameter("stuname");
		String born = req.getParameter("birthday");
		String sex = req.getParameter("sex");
		String school = req.getParameter("school");
		String classId = req.getParameter("classInfo");
		s.setId(Integer.valueOf(id));
		s.setName(name);
		s.setPwd(pwd);
		s.setDeptName(deptName);
		s.setBorn(born);
		s.setClassId(Integer.valueOf(classId));
		s.setSchool(school);
		s.setSex(sex);
		ss.updateStudent(s);
		resp.sendRedirect(req.getContextPath()+"/StudentQueryServlet");
	}

}
