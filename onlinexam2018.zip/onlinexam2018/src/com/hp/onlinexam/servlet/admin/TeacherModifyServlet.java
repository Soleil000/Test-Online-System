package com.hp.onlinexam.servlet.admin;

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hp.onlinexam.po.Teacher;
import com.hp.onlinexam.service.admin.IStuClassService;
import com.hp.onlinexam.service.admin.ITeacherService;
import com.hp.onlinexam.service.admin.StuClassService;
import com.hp.onlinexam.service.admin.TeacherService;
import com.hp.onlinexam.util.Department;
import com.hp.onlinexam.util.Encrypt;

@WebServlet("/TeacherModifyServlet")
public class TeacherModifyServlet extends HttpServlet{

	private ITeacherService ts = new TeacherService();
	private Teacher tc = new Teacher();
	private Encrypt e = new Encrypt();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id = req.getParameter("id");
		Map<String, Object> teaMap = ts.findTeacherInfo(Integer.valueOf(id));
		System.out.println(id);
		req.setAttribute("Teacher", teaMap);
		req.setAttribute("deptList", Department.values());
		req.getRequestDispatcher("manager/teachermodify.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id = req.getParameter("teacherId");
		String deptName = req.getParameter("depInfo");
		String password = req.getParameter("pwd");
		String pwd = e.convertMD5(password);
		String name = req.getParameter("teaname");
		tc.setId(Integer.valueOf(id));
		tc.setName(name);
		tc.setPwd(pwd);
		tc.setDeptName(deptName);
		ts.updateTeacher(tc, Integer.valueOf(id));
		resp.sendRedirect(req.getContextPath()+"/TeacherQueryServlet");
	}

}
