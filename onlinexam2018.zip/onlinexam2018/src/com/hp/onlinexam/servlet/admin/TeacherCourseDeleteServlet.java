package com.hp.onlinexam.servlet.admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hp.onlinexam.po.TeacherCourse;
import com.hp.onlinexam.service.admin.CourseService;
import com.hp.onlinexam.service.admin.ICourseService;


@WebServlet("/TeacherCourseDeleteServlet")
public class TeacherCourseDeleteServlet extends HttpServlet{
	private ICourseService cs = new CourseService();
	TeacherCourse tc = new TeacherCourse();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id = req.getParameter("id");
		cs.deleteTeacherCourse(Integer.valueOf(id));
		resp.sendRedirect(req.getContextPath()+"/TeacherCourseQueryServlet");
	}
	
}
