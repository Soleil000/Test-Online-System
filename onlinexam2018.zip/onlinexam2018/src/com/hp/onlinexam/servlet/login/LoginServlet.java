package com.hp.onlinexam.servlet.login;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hp.onlinexam.po.Student;
import com.hp.onlinexam.po.Teacher;
import com.hp.onlinexam.service.login.ILoginService;
import com.hp.onlinexam.service.login.LoginService;
import com.hp.onlinexam.util.Encrypt;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet{

	private ILoginService ls = new LoginService();
	private Encrypt e = new Encrypt();
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String userName = req.getParameter("username");
		String password = req.getParameter("pwd");
		String pwd = e.convertMD5(password);
		String checkCode = req.getParameter("validationCode");
		String saveCode = (String)req.getSession().getAttribute("check_code");
		String role = req.getParameter("role");
		if(!saveCode.equalsIgnoreCase(checkCode)) {
			req.setAttribute("msg", "验证码不正确!");  
            req.getRequestDispatcher("/login.jsp").forward(req, resp);  
            return;
		}
		if("admin".equals(role)) {
			if("admin".equals(userName)&&"e10adc3949ba59abbe56e057f20f883e".equals(password)){
				req.getSession().setAttribute("user", userName);
				req.getRequestDispatcher("/manager/mindex.jsp").forward(req, resp);
			}
			else {
				req.setAttribute("msg", "用户名或密码错误!");  
	            req.getRequestDispatcher("/login.jsp").forward(req, resp);  
			}
		}
		else if("teacher".equals(role)) {
			Teacher t = new Teacher();
			t.setName(userName);
			t.setPwd(pwd);
			t = ls.canLogin(t);
			if(null!=t) {
				/**
				 * session的作用域大于request
				 */
				req.getSession().setAttribute("user", t);
				req.getRequestDispatcher("teacher/tindex.jsp").forward(req, resp);	
			}
			else {
				req.setAttribute("msg", "用户名或密码错误!");  
	            req.getRequestDispatcher("/login.jsp").forward(req, resp);  
			}
				
		}
		else if("student".equals(role)) {
			Student s = new Student();
			s.setName(userName);
			s.setPwd(pwd);
			s = ls.canLogin(s);
			if(null!=s) {
				/**
				 * session的作用域大于request
				 */
				req.getSession().setAttribute("user", s);
				req.getRequestDispatcher("student/index.jsp").forward(req, resp);	
			}
			else {
				req.setAttribute("msg", "用户名或密码错误!");  
	            req.getRequestDispatcher("/login.jsp").forward(req, resp);  
			}
				
		}
	}

}
