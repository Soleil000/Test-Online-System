var myArray = ["item1", "item2", "item3", "itemn"];

$(document).ready(function(){
    var collect = '';
    for(var i = 0; i<myArray.length;i++){
        collect += '<option value="'+i+'">'+myArray[i]+'</option>';
    }
    document.getElementById("mySelect").innerHTML = collect;
})